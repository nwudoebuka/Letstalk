package com.newage.letstalk.services;

//@GlideModule
public class MyAppGlideModule //extends AppGlideModule
{

}

package com.newage.letstalk;

/**
 * Created by Newage_android on 7/12/2018.
 */

public class Updatecardview {

    public int me;
    public int you;

    public int getme() {

        return me;
    }
    public int getyou() {

        return you;
    }

    public void setme(int me) {

        this.me = me;
    }

    public void setyou(int you) {

        this.you = you;
    }

}

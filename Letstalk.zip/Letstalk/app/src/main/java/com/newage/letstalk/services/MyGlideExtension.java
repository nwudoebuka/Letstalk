package com.newage.letstalk.services;

import android.content.Context;
import android.support.annotation.NonNull;
import android.util.DisplayMetrics;



//@GlideExtension
public class MyGlideExtension {
    private MyGlideExtension() {}

//    @NonNull
//    @GlideOption
//    public static RequestOptions roundedCorners(RequestOptions options, @NonNull Context context, int cornerRadius) {
//        int px = Math.round(cornerRadius * (context.getResources().getDisplayMetrics().xdpi / DisplayMetrics.DENSITY_DEFAULT));
//        return options.transforms(new RoundedCorners(px));
//    }

}

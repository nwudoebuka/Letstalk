package com.newage.letstalk;
import android.os.Bundle;
import android.app.Activity;

/**
 * Created by Newage_android on 5/2/2018.
 */

public class NotificationView extends Activity{
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification);
    }
}

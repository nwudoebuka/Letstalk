package com.newage.letstalk;

/**
 * Created by Newage_android on 7/12/2018.
 */

public class Updatearray {

    public int firstarray;
    public int latestarray;

    public int first() {

        return firstarray;
    }
    public int latest() {

        return latestarray;
    }

    public void setfirst(int first) {

        this.firstarray = first;
    }

    public void setlatest(int latest) {

        this.latestarray = latest;
    }

}
